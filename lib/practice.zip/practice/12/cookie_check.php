<?php

var_dump($_COOKIE);

?>
<html>
<body>
<a href="cookie_set.php">戻る</a>
</body>
</html>