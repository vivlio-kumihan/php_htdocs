<html>
<head>
<meta charset="UTF-8">
<title>検索アプリ</title>
</head>
<body>
<h1>検索アプリ</h1>
<p>名前の一致する会員を一覧にしよう</p>
<form action="search_receive.php" method="POST">
<label>お名前</label>
<input type="text" name="name">
<input type="submit" value="検索する">
</form>
</body>
</html>