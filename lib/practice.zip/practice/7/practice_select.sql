SELECT id, email, tel FROM user WHERE id >= 2;
UPDATE user SET tel = '09077777777' WHERE id = 2;