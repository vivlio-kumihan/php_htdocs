<?php

$place = '北海道';
echo $place.'に行きたい';