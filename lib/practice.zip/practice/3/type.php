<?php
 
$str = 'こんにちは';
$int = 8;
$bool = TRUE;
$float = 3.2;
$null = NULL;

var_dump($str);
var_dump($int);
var_dump($bool);
var_dump($float);
var_dump($null);
