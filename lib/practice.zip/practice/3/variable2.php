<?php

$name = '鈴木';
$name = '佐藤';

echo $name;

