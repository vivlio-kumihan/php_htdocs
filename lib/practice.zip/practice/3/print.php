<?php

print '佐藤さん、こんばんは';