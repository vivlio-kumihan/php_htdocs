<?php

echo '鈴木さん、こんにちは';
