<?php
$x = 5;
$y = 7;
$z = 12;

echo $x + $y;
echo $y * $z;