<?php
$x = 3;
$y = 8;
$z = 17;

echo $z / ($y - $x).'<br>';
echo $z % ($z - ($x + $y));
