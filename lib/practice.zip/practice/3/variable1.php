<?php

$name = '鈴木';
echo $name;