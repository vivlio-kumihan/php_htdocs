<?php

for($i =1; $i <= 8; $i++){
	echo $i.'行目です。<br>';
}
