<html>
<body>

<?php for($i = 1; $i <= 5; $i++){ ?>
	<p><?php echo $i; ?>行目です。</p>
<?php } ?>

</body>
</html>