<?php
 
$i = 1;
 while($i <= 20){
  echo $i.'行目です。<br>';
  $i++;
}