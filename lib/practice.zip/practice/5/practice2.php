<?php 

$i= 1;
$sum = 1;

while($i <= 30){
	$sum *= 2;
	$i++;
}

echo '合計は'.$sum;