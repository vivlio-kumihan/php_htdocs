<html>
<head>
<style>
ul{width:100px;}
.color-red{background-color:red;}
</style>
</head>
<body>
 
<ul>
  <li class="color-red">1</li>
  <li>2</li>
  <li class="color-red">3</li>
  <li>4</li>
</ul>
 
</body>
</html>
