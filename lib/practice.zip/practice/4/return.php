<?php
$num = 5;
var_dump($num < 3);