<?php

$age = 23;

if($age < 20){
	echo '未成年です。';
}elseif($age >= 20){
	echo '成人です。';
}