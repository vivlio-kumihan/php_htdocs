<?php

$language = 2;

switch($language){
	case 1:
		echo 'こんにちは';
		break;
	case 2:
		echo 'Hello';
		break;
	case 3:
		echo 'Bonjour';
		break;
	default:
		echo '入力した数値が違っています。';
}
