<html>
<body>
<h1>画像アップ</h1>
<form action="pic_receive.php" method="post" enctype="multipart/form-data">
<p><input type="file" name="img"></p>
<p><input type="submit" value="送信"></p>
</form>
</body>
</html>