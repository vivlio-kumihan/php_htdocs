<?php

$array = array();

$array[] = 'リンゴ';
$array[] = 'みかん';
$array[] = 'バナナ';
var_dump($array);
