<?php
 
$arrays = array(
 
    1 => array(
    'name' => '鈴木',
    'hobby' => 'テニス',
    'email' => 'sample@sample.com'
    ),
    2 => array(
    'name' => '山田',
    'hobby' => 'パソコン',
    'email' => 'sample2@sample2.com'
    ),
    3 => array(
    'name' => '斉藤',
    'hobby' => '水泳',
    'email' => 'sample3@sample3.com'
    )
 
  );
echo $arrays[2]['name'];

 
