<?php

$array = array();

$array[] = 'リンゴ';
$array[] = 'みかん';
$array[] = 'バナナ';
echo $array[2];
