<?php
 
$array1 = array();//配列として初期化
$array2 = array();
 
$array1 = array('リンゴ', 'みかん', 'バナナ');
 
$array2 = array('name' => '鈴木', 'hobby' =>'テニス', 'email' => 'sample@sample.com');

var_dump($array1);
var_dump($array2);