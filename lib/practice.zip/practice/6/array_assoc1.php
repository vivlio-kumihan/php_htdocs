<?php
 
$array = array();//配列として初期化
 
$array['name'] = '鈴木';
$array['hobby'] = 'テニス';
$array['email'] = 'sample@sample.com';

var_dump($array);